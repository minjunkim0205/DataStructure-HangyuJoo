class ListNode {
    Object data;
    ListNode link;

    public ListNode() {
        data = null;
        link = null;
    }

    public ListNode(Object data) {
        this.data = data;
        this.link = null;
    }
}