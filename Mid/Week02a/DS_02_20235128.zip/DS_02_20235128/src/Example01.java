public class Example01 {
    public static void main(String[] args) {
        final int SIZE = 20;
        for(int n = 1; n <= SIZE; n++)
        {
            if(n%2==0)
            {
                System.out.print(n+" ");
            }
        }
    }
}
