public class Assignment02 {
    public static void main(String[] args) {

    }
}
